from ._destinations import Destinations

__all__ = ['Destinations']
