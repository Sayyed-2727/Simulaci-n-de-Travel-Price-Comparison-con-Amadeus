class Decorator(object):
    def __init__(self, client):
        self.client = client
